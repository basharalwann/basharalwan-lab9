﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace محاضره9_2
{
    public partial class Form2 : Form
    {
        public string getn1() => textBox1.Text;
        public string getop() => comboBox1.Text;
        public string getn2() => textBox2.Text;
        public string getr() => textBox3.Text;
        public Form2(string number1, string operation, string number2, string result)
        {
            InitializeComponent();
            textBox1.Text = number1;
            textBox2.Text = number2;
            comboBox1.Text = operation;
            textBox3.Text = result;

        }
       
           
        
    }
}

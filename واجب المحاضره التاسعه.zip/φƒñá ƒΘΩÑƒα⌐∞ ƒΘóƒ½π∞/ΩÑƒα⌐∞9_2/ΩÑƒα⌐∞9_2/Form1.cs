﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace محاضره9_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("+");
            comboBox1.Items.Add("-");
            comboBox1.Items.Add("*");
            comboBox1.Items.Add("/");
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n1 = Convert.ToInt16(textBox1.Text);
            int n2 = Convert.ToInt16(textBox2.Text);
            int z;
            string op = comboBox1.Text.Trim();
            switch (op)
            {
                case "+":
                    z = n1 + n2;
                    textBox3.Text = z.ToString();
                    break;
                case "-":
                    z = n1 - n2;
                    textBox3.Text = z.ToString();
                    break;
                case "*":
                    z = n1 * n2;
                    textBox3.Text = z.ToString();
                    break;
                case "/":
                    if (n2 != 0)
                    {
                        z = n1 / n2;
                        textBox3.Text = z.ToString();
                    }
                    else { MessageBox.Show("لايمكن قسمه على صفر"); }
                    break;
            }
            listBox1.Items.Add(textBox1.Text);
            listBox2.Items.Add(comboBox1.SelectedItem);
            listBox3.Items.Add(textBox2.Text);
            listBox4.Items.Add(textBox3.Text);
            textBox1.Text = textBox2.Text = textBox3.Text = null;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int ind = listBox1.SelectedIndex;
            listBox1.Items.RemoveAt(ind);

            listBox2.Items.RemoveAt(ind);

            listBox3.Items.RemoveAt(ind);

            //if (listBox4.SelectedItem != null)
            listBox4.Items.RemoveAt(ind);

        }
        private void up(int index)
        {
            listBox1.SelectedIndex = index;
            listBox2.SelectedIndex = index;
            listBox3.SelectedIndex = index;
            listBox4.SelectedIndex = index;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            up(listBox1.SelectedIndex);
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            up(listBox2.SelectedIndex);
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            up(listBox3.SelectedIndex);
        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            up(listBox4.SelectedIndex);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {//زر تعديل
         //int s = listBox1.SelectedIndex;
         //listBox1.Items[s] = textBox1.Text;
         //listBox2.Items[s] = comboBox1.Text;
         //listBox3.Items[s] = textBox2.Text;
         //listBox4.Items[s] = textBox3.Text;
            if (listBox1.SelectedIndex != -1)
            {
                // الحصول على البيانات المحددة
                int selectedIndex = listBox1.SelectedIndex;
                string number1 = listBox1.Items[selectedIndex].ToString();
                string operation = listBox2.Items[selectedIndex].ToString();
                string number2 = listBox3.Items[selectedIndex].ToString();
                string result = listBox4.Items[selectedIndex].ToString();
                Form2 f = new Form2(number1, operation, number2, result);
                f.ShowDialog();
                //// عرض النموذج وانتظار التعديل
                listBox1.Items[selectedIndex] = f.getn1();
                listBox2.Items[selectedIndex] = f.getop();
                listBox3.Items[selectedIndex] = f.getn2();
                listBox4.Items[selectedIndex] = f.getr();

                //    listName.Items[selectindex] = f.updatename;
                //    listNumber.Items[selectindex] = f.updatenumber;
                //    listAge.Items[selectindex] = f.updateage;
                //    listGender.Items[selectindex] = f.updateGender;
                MessageBox.Show("تم التعديل بنجاح");
                //}

            }
        }
    }
}
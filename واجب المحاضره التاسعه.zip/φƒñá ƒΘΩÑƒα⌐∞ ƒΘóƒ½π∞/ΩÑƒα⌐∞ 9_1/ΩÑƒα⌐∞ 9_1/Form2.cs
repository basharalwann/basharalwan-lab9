﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace محاضره_9_1
{
    public partial class Form2 : Form
    {
        public String getname() => textBox2.Text;
        public string getnumber() => textBox1.Text;
        public string getage() => textBox3.Text;
        public String getgender() => textBox4.Text;
        public Form2(string name, string number, string age, string gender)
        {
            InitializeComponent();
            textBox2.Text = name;
            textBox1.Text = number;
            textBox3.Text = age;


            textBox4.Text = gender;

            textBox4.ReadOnly = true;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

            if (radioButton1.Checked)
            {
                textBox4.Text = radioButton1.Text;
            }
            else
            {
                textBox4.Text = radioButton2.Text;
            }
        }
    }
    }
    

    
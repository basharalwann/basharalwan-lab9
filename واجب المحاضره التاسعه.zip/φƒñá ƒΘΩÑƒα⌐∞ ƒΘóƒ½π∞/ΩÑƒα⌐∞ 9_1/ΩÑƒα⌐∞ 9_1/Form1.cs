﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace محاضره_9_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {//اضافه
            if (textBox1.Text != null && textBox2.Text != null && textBox3.Text != null &&( radioButton1.Checked != false || radioButton2.Checked != false))
            {
                listBox1.Items.Add(textBox1.Text);
                listBox2.Items.Add(textBox2.Text);
                listBox3.Items.Add(textBox3.Text);
                if (radioButton1.Checked)
                {
                    listBox4.Items.Add(radioButton1.Text);
                }
                else if (radioButton2.Checked)
                {
                    listBox4.Items.Add(radioButton2.Text);
                }
                textBox1.Text = textBox2.Text = textBox3.Text = null;
                radioButton1.Checked = false;
            }
            else
                MessageBox.Show("يرجاء ملئ جميع الحقول");
 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //حذف مظللل
            int ind= listBox1.SelectedIndex;
            listBox1.Items.RemoveAt(ind);

            listBox2.Items.RemoveAt(ind);

             listBox3.Items.RemoveAt(ind);

                //if (listBox4.SelectedItem != null)
             listBox4.Items.RemoveAt(ind);
            
 
        }
        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            //int s = listBox1.SelectedIndex;
            //listBox4.SelectedIndex = listBox3.SelectedIndex = listBox1.SelectedIndex =s;
            //listBox4.SelectedIndex = listBox3.SelectedIndex =
            //   listBox1.SelectedIndex = listBox2.SelectedIndex;
            up(listBox2.SelectedIndex);

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //listBox4.SelectedIndex = listBox3.SelectedIndex =
            //   listBox2.SelectedIndex = listBox1.SelectedIndex;
            up(listBox1.SelectedIndex);
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            //listBox4.SelectedIndex = listBox1.SelectedIndex =
            //   listBox2.SelectedIndex = listBox3.SelectedIndex;
            up(listBox3.SelectedIndex);
        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            //listBox3.SelectedIndex = listBox1.SelectedIndex =
            //   listBox2.SelectedIndex = listBox4.SelectedIndex;
            up(listBox4.SelectedIndex);
        }
        private void up(int index)
        {
            listBox1.SelectedIndex = index;
            listBox2.SelectedIndex = index;
            listBox3.SelectedIndex = index;
            listBox4.SelectedIndex = index;
        }

        private void button3_Click(object sender, EventArgs e)
        {//حذف الكل
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //textBox1.Text = listBox1.SelectedItem.ToString() ;
            //int s = listBox1.SelectedIndex;
            //listBox1.Items[s] = textBox1.Text;
            //listBox2.Items[s] = textBox2.Text;
            //listBox3.Items[s] = textBox3.Text;
            //if (radioButton1.Checked)
            //{
            //    listBox4.Items[s] = radioButton1.Text;
            //}
            //else if (radioButton2.Checked)
            //{
            //    listBox4.Items[s] = radioButton2.Text;
            //}
             if (listBox2.SelectedIndex >= 0)
            {
                int selectindex = listBox2.SelectedIndex;
                String name = listBox2.SelectedItem.ToString();
                String number = listBox1.SelectedItem.ToString();
                String age = listBox3.SelectedItem.ToString();
                String gender = listBox4.SelectedItem.ToString();

                Form2 f = new Form2(name,number, age, gender);
                f.ShowDialog();
                //if (f.ShowDialog() == DialogResult.OK)
                //{
                    listBox1.Items[selectindex] = f.getnumber();
                    listBox2.Items[selectindex] = f.getname();
                    listBox3.Items[selectindex] = f.getage();
                    listBox4.Items[selectindex] = f.getgender();
                   
                //    listName.Items[selectindex] = f.updatename;
                //    listNumber.Items[selectindex] = f.updatenumber;
                //    listAge.Items[selectindex] = f.updateage;
                //    listGender.Items[selectindex] = f.updateGender;
                   MessageBox.Show("تم التعديل بنجاح");
                //}

            }
            else
                MessageBox.Show("يرجى اختيار عنصر للتعديل");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < 48 || e.KeyChar > 57)
              e.Handled = true;
             if (e.KeyChar == 8)
                e.Handled = false;
}

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!((e.KeyChar >= 'a' && e.KeyChar <= 'z') || (e.KeyChar >= 'A' && e.KeyChar <= 'Z')
                    || (e.KeyChar >= 'ا' && e.KeyChar <= 'ي') || (e.KeyChar == 8)))
                e.Handled = true;
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < 48 || e.KeyChar > 57)
                e.Handled = true;
            if (e.KeyChar == 8)
               e.Handled = false;

        }
    }
    }

